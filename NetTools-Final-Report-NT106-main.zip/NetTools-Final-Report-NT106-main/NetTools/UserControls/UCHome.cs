﻿using System.Windows.Forms;

namespace NetTools.UserControls
{
    public partial class UCHome : UserControl
    {
        public UCHome()
        {
            InitializeComponent();
        }
    }
}
