﻿using System.Windows.Forms;

namespace NetTools.UserControls
{
    public partial class UCSetting : UserControl
    {
        public UCSetting()
        {
            InitializeComponent();
        }
    }
}
